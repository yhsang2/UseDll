﻿using System;

namespace Test_CreateDLL
{
    public class dllTest
    {
        public int fn_Add(int a, int b)
        {
            return a + b;
        }
    }
}
